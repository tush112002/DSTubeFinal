  <template>
      <div class="home">
        <Card/>
      </div>
    </template>
    
    <script setup>
    import Card from './Card.vue'
    </script>
    
    <style scoped>
    .home {
      padding: 20px;
      margin-top: 70px;
    }
    </style>
    